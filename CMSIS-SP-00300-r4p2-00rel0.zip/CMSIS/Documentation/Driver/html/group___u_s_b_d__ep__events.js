var group___u_s_b_d__ep__events =
[
    [ "ARM_USBD_EVENT_IN", "group___u_s_b_d__ep__events.html#ga375d3d8f363a056ff607c5ab3b92a864", null ],
    [ "ARM_USBD_EVENT_OUT", "group___u_s_b_d__ep__events.html#ga35f7340508acb5fe7a5f43bbcac1887a", null ],
    [ "ARM_USBD_EVENT_SETUP", "group___u_s_b_d__ep__events.html#gaa0814f6880f4c0ac302ac9ebc8170739", null ]
];