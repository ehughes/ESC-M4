var group__i2c__bus__speed__ctrls =
[
    [ "ARM_I2C_BUS_SPEED_FAST", "group__i2c__bus__speed__ctrls.html#ga39f49ef4cd1100a8d9dc9003329e5ecd", null ],
    [ "ARM_I2C_BUS_SPEED_FAST_PLUS", "group__i2c__bus__speed__ctrls.html#ga2615262062e0327ab478ec85675ca649", null ],
    [ "ARM_I2C_BUS_SPEED_HIGH", "group__i2c__bus__speed__ctrls.html#ga10aae5a8c7fcc90e514c5fb7393056ec", null ],
    [ "ARM_I2C_BUS_SPEED_STANDARD", "group__i2c__bus__speed__ctrls.html#ga0aaa6398280fdd7ad651d7d6d44c863f", null ]
];