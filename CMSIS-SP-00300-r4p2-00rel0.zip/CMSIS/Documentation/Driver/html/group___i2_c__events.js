var group___i2_c__events =
[
    [ "ARM_I2C_EVENT_ADDRESS_NACK", "group___i2_c__events.html#ga98b815769634d9578526b43589caa017", null ],
    [ "ARM_I2C_EVENT_ARBITRATION_LOST", "group___i2_c__events.html#gac9000f44a578e2117d64dbc2093cec6d", null ],
    [ "ARM_I2C_EVENT_BUS_CLEAR", "group___i2_c__events.html#ga81ca21fad73dac1ffaff58921f848ea9", null ],
    [ "ARM_I2C_EVENT_BUS_ERROR", "group___i2_c__events.html#gaeef542840355131c18b53fd9ed1904a8", null ],
    [ "ARM_I2C_EVENT_GENERAL_CALL", "group___i2_c__events.html#ga3ab54410b6410ed3a58762ff0c0d68b9", null ],
    [ "ARM_I2C_EVENT_SLAVE_RECEIVE", "group___i2_c__events.html#gabd875b57ce39dadd849c53b885ad6661", null ],
    [ "ARM_I2C_EVENT_SLAVE_TRANSMIT", "group___i2_c__events.html#gacfbbec9af083d35e8ea87ad16e9c6ec2", null ],
    [ "ARM_I2C_EVENT_TRANSFER_DONE", "group___i2_c__events.html#ga5992dc0f6e839c4d066cfa83d535f30d", null ],
    [ "ARM_I2C_EVENT_TRANSFER_INCOMPLETE", "group___i2_c__events.html#gafac3989c7b57727e1bed4ee9f2496ac9", null ]
];