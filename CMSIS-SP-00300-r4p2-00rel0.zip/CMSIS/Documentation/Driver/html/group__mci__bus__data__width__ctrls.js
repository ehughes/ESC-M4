var group__mci__bus__data__width__ctrls =
[
    [ "ARM_MCI_BUS_DATA_WIDTH_1", "group__mci__bus__data__width__ctrls.html#gaa09a00d810a4dfd1d1824311ee290585", null ],
    [ "ARM_MCI_BUS_DATA_WIDTH_4", "group__mci__bus__data__width__ctrls.html#gaa28150d8c3789e8cf1bcda318f74a28c", null ],
    [ "ARM_MCI_BUS_DATA_WIDTH_4_DDR", "group__mci__bus__data__width__ctrls.html#gaccb174bd131f8fd8cd9a56439a8ebb60", null ],
    [ "ARM_MCI_BUS_DATA_WIDTH_8", "group__mci__bus__data__width__ctrls.html#ga3bb99a2d98ba9fb8c5bc97fa2b8ef469", null ],
    [ "ARM_MCI_BUS_DATA_WIDTH_8_DDR", "group__mci__bus__data__width__ctrls.html#ga7b31f81ae703229095fe9efcfbe80b47", null ]
];