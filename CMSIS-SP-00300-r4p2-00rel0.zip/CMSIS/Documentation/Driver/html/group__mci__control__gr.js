var group__mci__control__gr =
[
    [ "MCI Controls", "group__mci__mode__ctrls.html", "group__mci__mode__ctrls" ],
    [ "MCI Bus Speed Mode", "group__mci__bus__speed__ctrls.html", "group__mci__bus__speed__ctrls" ],
    [ "MCI Bus Data Width", "group__mci__bus__data__width__ctrls.html", "group__mci__bus__data__width__ctrls" ],
    [ "MCI CMD Line Mode", "group__mci__cmd__line__ctrls.html", "group__mci__cmd__line__ctrls" ],
    [ "MCI Driver Strength", "group__mci__driver__strength__ctrls.html", "group__mci__driver__strength__ctrls" ]
];