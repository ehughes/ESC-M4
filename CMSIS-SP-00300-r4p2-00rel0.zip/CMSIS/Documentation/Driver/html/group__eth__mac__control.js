var group__eth__mac__control =
[
    [ "Ethernet MAC Controls", "group__eth__mac__ctrls.html", "group__eth__mac__ctrls" ],
    [ "Ethernet MAC Configuration", "group__eth__mac__configuration__ctrls.html", "group__eth__mac__configuration__ctrls" ],
    [ "Ethernet MAC Flush Flags", "group__eth__mac__flush__flag__ctrls.html", "group__eth__mac__flush__flag__ctrls" ],
    [ "Ethernet MAC VLAN Filter Flag", "group__eth__mac__vlan__filter__ctrls.html", "group__eth__mac__vlan__filter__ctrls" ]
];