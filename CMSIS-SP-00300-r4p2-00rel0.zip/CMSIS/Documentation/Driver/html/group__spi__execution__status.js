var group__spi__execution__status =
[
    [ "ARM_SPI_ERROR_BIT_ORDER", "group__spi__execution__status.html#ga6b8ac31930ea6ca3a9635f2ac935466d", null ],
    [ "ARM_SPI_ERROR_DATA_BITS", "group__spi__execution__status.html#ga76f895d3380ca474124f83acbebc5651", null ],
    [ "ARM_SPI_ERROR_FRAME_FORMAT", "group__spi__execution__status.html#gac47584fe5691889c056611bc589b25aa", null ],
    [ "ARM_SPI_ERROR_MODE", "group__spi__execution__status.html#ga273a55c5d19491c565e5f05d03d66f3f", null ],
    [ "ARM_SPI_ERROR_SS_MODE", "group__spi__execution__status.html#gaae7b1a1feb46faa1830c92b73bd775ad", null ]
];