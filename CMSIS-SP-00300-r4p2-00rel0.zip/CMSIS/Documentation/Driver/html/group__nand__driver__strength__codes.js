var group__nand__driver__strength__codes =
[
    [ "ARM_NAND_DRIVER_STRENGTH_18", "group__nand__driver__strength__codes.html#ga942e20df12022f3bbd0e9a558ec1c7a0", null ],
    [ "ARM_NAND_DRIVER_STRENGTH_25", "group__nand__driver__strength__codes.html#ga17188e039f5f87c581033327399a057d", null ],
    [ "ARM_NAND_DRIVER_STRENGTH_35", "group__nand__driver__strength__codes.html#ga33562a66a5bf328eea82b2f1893a7874", null ],
    [ "ARM_NAND_DRIVER_STRENGTH_50", "group__nand__driver__strength__codes.html#gaa502e2c995447037d266f939faa43223", null ]
];