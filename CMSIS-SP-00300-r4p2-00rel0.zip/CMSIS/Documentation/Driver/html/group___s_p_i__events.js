var group___s_p_i__events =
[
    [ "ARM_SPI_EVENT_DATA_LOST", "group___s_p_i__events.html#ga8e63d99c80ea56de596a8d0a51fd8244", null ],
    [ "ARM_SPI_EVENT_MODE_FAULT", "group___s_p_i__events.html#ga7eaa229003689aa18598273490b3e630", null ],
    [ "ARM_SPI_EVENT_TRANSFER_COMPLETE", "group___s_p_i__events.html#gaabdfc9e17641144cd50d36d15511a1b8", null ]
];