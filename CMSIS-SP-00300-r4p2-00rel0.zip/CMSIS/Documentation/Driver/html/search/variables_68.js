var searchData=
[
  ['high_5fspeed',['high_speed',['../group__mci__interface__gr.html#a83ecf7d4472c55362750ef72d8f8f47d',1,'ARM_MCI_CAPABILITIES']]]
];
