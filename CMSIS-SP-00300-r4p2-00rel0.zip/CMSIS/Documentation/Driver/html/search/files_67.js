var searchData=
[
  ['general_2etxt',['General.txt',['../_general_8txt.html',1,'']]]
];
