var searchData=
[
  ['status_20error_20codes',['Status Error Codes',['../group__execution__status.html',1,'']]],
  ['status_20error_20codes',['Status Error Codes',['../group__nand__execution__status.html',1,'']]],
  ['spi_20bit_20order',['SPI Bit Order',['../group__spi__bit__order__ctrls.html',1,'']]],
  ['spi_20control_20codes',['SPI Control Codes',['../group___s_p_i__control.html',1,'']]],
  ['spi_20data_20bits',['SPI Data Bits',['../group__spi__data__bits__ctrls.html',1,'']]],
  ['spi_20events',['SPI Events',['../group___s_p_i__events.html',1,'']]],
  ['status_20error_20codes',['Status Error Codes',['../group__spi__execution__status.html',1,'']]],
  ['spi_20frame_20format',['SPI Frame Format',['../group__spi__frame__format__ctrls.html',1,'']]],
  ['spi_20interface',['SPI Interface',['../group__spi__interface__gr.html',1,'']]],
  ['spi_20miscellaneous_20controls',['SPI Miscellaneous Controls',['../group__spi__misc__ctrls.html',1,'']]],
  ['spi_20mode_20controls',['SPI Mode Controls',['../group__spi__mode__ctrls.html',1,'']]],
  ['spi_20slave_20select_20mode',['SPI Slave Select Mode',['../group__spi__slave__select__mode__ctrls.html',1,'']]],
  ['status_20error_20codes',['Status Error Codes',['../group__usart__execution__status.html',1,'']]]
];
