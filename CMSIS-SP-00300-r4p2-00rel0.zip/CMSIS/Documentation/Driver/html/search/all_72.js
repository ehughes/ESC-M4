var searchData=
[
  ['rb_5fmonitor',['rb_monitor',['../group__nand__interface__gr.html#a69f5e734ee4a9bb501718cf78a740c3e',1,'ARM_NAND_CAPABILITIES']]],
  ['read_5fwait',['read_wait',['../group__mci__interface__gr.html#a5e38e4ee9cebcc99904e287adc8e6217',1,'ARM_MCI_CAPABILITIES']]],
  ['readcd',['ReadCD',['../group__mci__interface__gr.html#aa4285dd6b0f9b8ca41b6710a478ad641',1,'ARM_DRIVER_MCI']]],
  ['readdata',['ReadData',['../group__nand__interface__gr.html#aeba263544c0d63ec8c29e919232615cb',1,'ARM_DRIVER_NAND::ReadData()'],['../group__flash__interface__gr.html#adec45569a2f6f0d915a206f8f19107bd',1,'ARM_DRIVER_FLASH::ReadData()']]],
  ['readframe',['ReadFrame',['../group__eth__mac__interface__gr.html#a466b724be2167ea7d9a14569062a8fa8',1,'ARM_DRIVER_ETH_MAC']]],
  ['readsetuppacket',['ReadSetupPacket',['../group__usbd__interface__gr.html#ab5593bf9bb516cc7b36c6072fc55260f',1,'ARM_DRIVER_USBD']]],
  ['readwp',['ReadWP',['../group__mci__interface__gr.html#aee6f8b38f83a51ac05cc4841524b708d',1,'ARM_DRIVER_MCI']]],
  ['receive',['Receive',['../group__spi__interface__gr.html#adb9224a35fe16c92eb0dd103638e4cf3',1,'ARM_DRIVER_SPI::Receive()'],['../group__usart__interface__gr.html#adb9224a35fe16c92eb0dd103638e4cf3',1,'ARM_DRIVER_USART::Receive()']]],
  ['reentrant_5foperation',['reentrant_operation',['../group__nand__interface__gr.html#ae0514834750c7452431717a881471e2b',1,'ARM_NAND_CAPABILITIES']]],
  ['reference_20implementation',['Reference Implementation',['../_reference_implementation.html',1,'']]],
  ['reserved',['reserved',['../group__nand__interface__gr.html#aa43c4c21b173ada1b6b7568956f0d650',1,'ARM_NAND_ECC_INFO']]],
  ['ri',['ri',['../group__usart__interface__gr.html#aa6cf03b82235bedc0acf00acb46130fb',1,'ARM_USART_MODEM_STATUS::ri()'],['../group__usart__interface__gr.html#aa6cf03b82235bedc0acf00acb46130fb',1,'ARM_USART_CAPABILITIES::ri()']]],
  ['rst_5fn',['rst_n',['../group__mci__interface__gr.html#a2e8bd27f2c5c3093c4fec557890b97d4',1,'ARM_MCI_CAPABILITIES']]],
  ['rts',['rts',['../group__usart__interface__gr.html#afad044722f459552e9f0f602983659e9',1,'ARM_USART_CAPABILITIES']]],
  ['rx_5fbreak',['rx_break',['../group__usart__interface__gr.html#aa5e3fa74f444688f9e727ffc1e988e5d',1,'ARM_USART_STATUS']]],
  ['rx_5fbusy',['rx_busy',['../group__usart__interface__gr.html#a9f5baee58ed41b382628a82a0b1cbcb4',1,'ARM_USART_STATUS']]],
  ['rx_5fframing_5ferror',['rx_framing_error',['../group__usart__interface__gr.html#af1d1cfd8b231843d5cc23e6a2b1ca8d0',1,'ARM_USART_STATUS']]],
  ['rx_5foverflow',['rx_overflow',['../group__usart__interface__gr.html#ac403aefd9bce8b0172e1996c0f3dd8aa',1,'ARM_USART_STATUS']]],
  ['rx_5fparity_5ferror',['rx_parity_error',['../group__usart__interface__gr.html#affb21b610e2d0d71727702441c238f4f',1,'ARM_USART_STATUS']]]
];
