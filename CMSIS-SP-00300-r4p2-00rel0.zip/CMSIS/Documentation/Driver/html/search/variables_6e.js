var searchData=
[
  ['ns',['ns',['../group__eth__mac__interface__gr.html#a048317f84621fb38ed0bf8c8255e26f0',1,'ARM_ETH_MAC_TIME']]]
];
