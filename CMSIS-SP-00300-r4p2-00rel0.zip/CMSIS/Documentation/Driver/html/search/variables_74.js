var searchData=
[
  ['ti_5fssi',['ti_ssi',['../group__spi__interface__gr.html#a8053c540e5d531b692224bdc2463f36a',1,'ARM_SPI_CAPABILITIES']]],
  ['transfer',['Transfer',['../group__spi__interface__gr.html#ad88b63ed74c03ba06b0599ab06ad4cf7',1,'ARM_DRIVER_SPI::Transfer()'],['../group__usart__interface__gr.html#ad88b63ed74c03ba06b0599ab06ad4cf7',1,'ARM_DRIVER_USART::Transfer()']]],
  ['transfer_5factive',['transfer_active',['../group__mci__interface__gr.html#a2655d3422b720097b091a28e8bbcea8f',1,'ARM_MCI_STATUS']]],
  ['transfer_5ferror',['transfer_error',['../group__mci__interface__gr.html#a21d4bc1a03e161bd33693619039a6afa',1,'ARM_MCI_STATUS']]],
  ['transfer_5ftimeout',['transfer_timeout',['../group__mci__interface__gr.html#a598ae4a196316d6dcb97d07fd337ecdd',1,'ARM_MCI_STATUS']]],
  ['tx_5fbusy',['tx_busy',['../group__usart__interface__gr.html#a2c6d2b67fba3f3e084e96a6bc7fcac6b',1,'ARM_USART_STATUS']]],
  ['tx_5funderflow',['tx_underflow',['../group__usart__interface__gr.html#a048f45e9d2257a21821f81d9edd17b72',1,'ARM_USART_STATUS']]],
  ['type',['type',['../group__nand__interface__gr.html#ad44b615021ed3ccb734fcaf583ef4a03',1,'ARM_NAND_ECC_INFO']]]
];
