var searchData=
[
  ['uhs_5fddr50',['uhs_ddr50',['../group__mci__interface__gr.html#a1ee73c19020d5f1bedf7c013d0e5f730',1,'ARM_MCI_CAPABILITIES']]],
  ['uhs_5fdriver_5ftype_5fa',['uhs_driver_type_a',['../group__mci__interface__gr.html#afe5de4fdc6657aa19fa87577a8d460e5',1,'ARM_MCI_CAPABILITIES']]],
  ['uhs_5fdriver_5ftype_5fc',['uhs_driver_type_c',['../group__mci__interface__gr.html#a3c3df9641e7216dd20d3bc395dc4948f',1,'ARM_MCI_CAPABILITIES']]],
  ['uhs_5fdriver_5ftype_5fd',['uhs_driver_type_d',['../group__mci__interface__gr.html#a639bebbcb9a3a743f4f232fec82e2bfc',1,'ARM_MCI_CAPABILITIES']]],
  ['uhs_5fsdr104',['uhs_sdr104',['../group__mci__interface__gr.html#ae07ceef1800252495a79f225142740e7',1,'ARM_MCI_CAPABILITIES']]],
  ['uhs_5fsdr50',['uhs_sdr50',['../group__mci__interface__gr.html#a5c3dcb2f8aa6f65408d9a6741abb7b3e',1,'ARM_MCI_CAPABILITIES']]],
  ['uhs_5fsignaling',['uhs_signaling',['../group__mci__interface__gr.html#a084188480d589cdc8d3e164b9f41bea9',1,'ARM_MCI_CAPABILITIES']]],
  ['uhs_5ftuning',['uhs_tuning',['../group__mci__interface__gr.html#a617bf7fb73b49a20398b90098ecc3ec0',1,'ARM_MCI_CAPABILITIES']]],
  ['uninitialize',['Uninitialize',['../group__eth__mac__interface__gr.html#adcf20681a1402869ecb5c6447fada17b',1,'ARM_DRIVER_ETH_MAC::Uninitialize()'],['../group__eth__phy__interface__gr.html#adcf20681a1402869ecb5c6447fada17b',1,'ARM_DRIVER_ETH_PHY::Uninitialize()'],['../group__i2c__interface__gr.html#adcf20681a1402869ecb5c6447fada17b',1,'ARM_DRIVER_I2C::Uninitialize()'],['../group__mci__interface__gr.html#adcf20681a1402869ecb5c6447fada17b',1,'ARM_DRIVER_MCI::Uninitialize()'],['../group__nand__interface__gr.html#adcf20681a1402869ecb5c6447fada17b',1,'ARM_DRIVER_NAND::Uninitialize()'],['../group__flash__interface__gr.html#adcf20681a1402869ecb5c6447fada17b',1,'ARM_DRIVER_FLASH::Uninitialize()'],['../group__spi__interface__gr.html#adcf20681a1402869ecb5c6447fada17b',1,'ARM_DRIVER_SPI::Uninitialize()'],['../group__usart__interface__gr.html#adcf20681a1402869ecb5c6447fada17b',1,'ARM_DRIVER_USART::Uninitialize()'],['../group__usbd__interface__gr.html#adcf20681a1402869ecb5c6447fada17b',1,'ARM_DRIVER_USBD::Uninitialize()'],['../group__usbh__host__gr.html#adcf20681a1402869ecb5c6447fada17b',1,'ARM_DRIVER_USBH::Uninitialize()'],['../group__usbh__hci__gr.html#adcf20681a1402869ecb5c6447fada17b',1,'ARM_DRIVER_USBH_HCI::Uninitialize()']]]
];
