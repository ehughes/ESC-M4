var searchData=
[
  ['theory_20of_20operation',['Theory of Operation',['../_theory_operation.html',1,'']]]
];
