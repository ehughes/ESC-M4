var group__usbh__interface__gr =
[
    [ "USB Host", "group__usbh__host__gr.html", "group__usbh__host__gr" ],
    [ "USB OHCI/EHCI", "group__usbh__hci__gr.html", "group__usbh__hci__gr" ]
];