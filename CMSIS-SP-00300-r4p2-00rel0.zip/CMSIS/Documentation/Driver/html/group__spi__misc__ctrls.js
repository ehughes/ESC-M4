var group__spi__misc__ctrls =
[
    [ "ARM_SPI_ABORT_TRANSFER", "group__spi__misc__ctrls.html#ga44708b80e48984be099cd6eb11780dc3", null ],
    [ "ARM_SPI_CONTROL_SS", "group__spi__misc__ctrls.html#ga5776272b82decff92da003568540c92f", null ],
    [ "ARM_SPI_GET_BUS_SPEED", "group__spi__misc__ctrls.html#gafc00fe35bb4c89b076d014b43168b2b3", null ],
    [ "ARM_SPI_SET_BUS_SPEED", "group__spi__misc__ctrls.html#ga5ef3d114979f3fd6010d0df16c2bf5c1", null ],
    [ "ARM_SPI_SET_DEFAULT_TX_VALUE", "group__spi__misc__ctrls.html#gae9861221dee78d52bd1522b7846535ce", null ]
];